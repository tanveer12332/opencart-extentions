<?php
// Heading
$_['heading_title']					 = 'NAB Transact Direct Post';

// Text
$_['text_payment']					 = 'Payment';
$_['text_success']					 = 'Success: You have modified NAB Transact Direct Post payment gateway details!';
$_['text_edit']                      = 'Edit NAB Transact Direct Post payment gateway';
$_['text_authorization']			= 'Pre-Authorization';
$_['text_authorization_riskm']		= 'Pre-Authorization with Risk Management';
$_['text_payment_riskm']			= 'Payment with Risk Management';


// Entry
$_['entry_username']				 = 'Merchant ID';
$_['entry_password']				 = 'Live Mode Password';
$_['entry_password_test_mode']		 = 'Test Mode Password';
$_['entry_test']					 = 'Test Mode';
$_['entry_transaction']				 = 'Transaction Method:';
$_['entry_debug']					 = 'Debug Mode';
$_['entry_total']					 = 'Total';
$_['entry_completed_status']		 = 'Completed Status';
$_['entry_failed_status']			 = 'Failed Status';
$_['entry_geo_zone']				 = 'Geo Zone';
$_['entry_status']					 = 'Status';
$_['entry_sort_order']				 = 'Sort Order';

// Tab
$_['tab_general']					 = 'General';
$_['tab_order_status']       		 = 'Order Status';

// Help
$_['help_test']						 = 'Use the live or testing (sandbox) gateway server to process transactions?';
$_['help_debug']			    	 = 'Logs additional information to the system log';
$_['help_total']					 = 'The checkout total the order must reach before this payment method becomes active';

// Error
$_['error_permission']				 = 'Warning: You do not have permission to modify payment NAB Transact Direct Post!';
$_['error_username']				 = 'Merchant ID required!';
$_['error_password']				 = 'Password required!';
$_['error_password_test_mode']		 = 'Test mode password required!';