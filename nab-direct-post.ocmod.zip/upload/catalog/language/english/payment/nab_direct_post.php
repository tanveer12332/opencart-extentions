<?php
// Text
$_['text_title']	= 'Visa or MasterCard (Processed securely by NAB)';
$_['text_testmode']	= 'Warning: The payment gateway is in \'Test Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';
$_['text_credit_card']			= 'Credit Card Details';
// Entry
$_['entry_cc_number']			= 'Card Number';
$_['entry_cc_expire_date']		= 'Card Expiry Date';
$_['entry_cc_ccv']				= 'The Card Check Value (CCV)';